# *The Standard Library* 

theme
:  lightning-monochrome

# Fresh Install

    $ sudo pacman -S ruby

# Internet Connection Dies!

# No Gems!

# Now What?

# Not all is lost!

# Out The Box

# Storage

# Servers

# Distributed Computing

# And more!

# Storage

# Key/Value FTW!

# MongoDB

# CouchDB

# BerkleyDB

# BerkleyDB?

# History

# 1992 Berkley...

# 1996 Sleepycat Software...

# 2006 Oracle

# Pervasive on UNIX

# 256TB DB Size

# 4GB Data Size

# Simple

# Fast

# *DBM*

# DBM 
    require "dbm"

    db = DBM.new('data')
    db['key'] = value
    db.close
{: lang="ruby"}

# But...

# No Concurrent Access

# No Network Interface

# *DEMO*

# Berkley DB is first choice

# Other Backends

# gdbm GNU DBM

# sdbm Ruby DBM

# Distributed Computing

# Halp! I can't use Resque!

# *DRb*!

# Distributed Ruby

# Time Server - Server

    require 'drb/drb'

    $SAFE = 1 # Disable eval
    
    class TimeServer
      def get_current_time
        return Time.now
      end
    end

    DRb.start_service('druby://localhost:8787', TimeServer.new)
    DRb.thread.join
{: lang="ruby"}

# Time Server - Client
    require 'drb/drb'
    
    DRb.start_service
    time_server = DRbObject.new_with_uri('druby://localhost:8787')

    puts time_server.get_current_time
{: lang="ruby"}

# *DEMO*
 
# Client/Server

# DRb for Ruby

# What about everyone else?

# *GServer*!

# Generic Server

# Subclass GServer 

# Implement serve(io)

# TimeServer - Server
    require 'gserver'

    class TimeServer < GServer
      def serve(io)
        io.puts(Time.now.to_s)
      end
    end

    TimeServer.new(9797).start
{: lang="ruby"}

# Support any protocol!

# The possibilities are endless!

# *DEMO*

# GIVE ME MORE GOODIES!

# *Abbrev*

# Abbreviations

# Abbrev
    require 'abbrev'

    ["dog", "fox", "fax"].abbrev

    {"dog" => "dog",
    "do"   => "dog",
    "d"    => "dog",
    "fox"  => "fox",
    "fo"   => "fox",
    "fax"  => "fax",
    "fa"   => "fax"}
{: lang="ruby"}

# Abbrev
    Hash[
      *['dog','fox','fax'].abbrev.group_by |k,v| v }.
         map{ |k,v| [k, v.map{|a|a[0]}.sort.first]}.
         flatten 
    ]

    {"dog" => "d",
    "fox"  => "fo",
    "fax"  => "fa"}
{: lang="ruby"}

# *Curses*

# GUI is for WIMPs

# *DEMO*

# *Fiddle*

# Foreign Function Interface

# Use any .so library!

# The possibilities are endless!

# *DEMO*

# Export Formats?

# *REXML*

# *JSON*

# Testing?

# *Test::Unit*

# *MiniTest*

# System Admin?

# *Shell*

    require 'shell'
    sh = Shell.cd("/tmp")
    sh.transact do
      mkdir "shell-test-1" unless exists?("shell-test-1")
      cd("shell-test-1")
      for dir in ["dir1", "dir3", "dir5"]
        if !exists?(dir)
          mkdir dir
          cd(dir) do
            f = open("tmpFile", "w")
            f.print "TEST\n"
            f.close
          end
          print pwd
        end
      end
    end
{: lang="ruby"}

# Internet Back?

# *Net::HTTP*

# *Net::FTP*

# *Net::SMTP*

# *Net::POP*

# *Net::IMAP*

# DRb Not Good Enough?

# *Rinda*

# Linda 
 
# Shared Tuplespace

# Shared Memory

# *DEMO*

# Console is for Luddites!

# GUI

# *Tk*

# *DEMO*

# Windows?

# Win32OLE
    require 'win32ole'
    
    olHTML = 5
    outlook = WIN32OLE.connect("Outlook.Application")
    mapi = outlook.GetNameSpace("MAPI")
    inbox = mapi.GetDefaultFolder(6)
    msg = inbox.Items(2)
    msg.SaveAs('c:\temp\message.htm', olHTML)
{: lang="ruby"}

# Ruby Doc 

# Questions?
