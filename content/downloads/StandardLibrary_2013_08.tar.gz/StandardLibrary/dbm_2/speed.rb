require 'dbm'

start = Time.now
DBM.open( 'data', 0666, DBM::NEWDB ) do |db|
  100000.times do |i|
    key = i.to_s
    value = '*' * rand( 1024 )
    db[ key ] = value
  end
end

finish = Time.now
puts( format( "Wrote 100K Records in %.2f seconds", finish - start ))

sleep( 1 )

start = Time.now
DBM.open( 'data', 0666, DBM::READER ) do |db|
  db.each_pair do |k,v|
    # Do stuff
  end
end
finish = Time.now
puts( format( "Read 100K Records in %.2f seconds", finish - start ))
