require 'gserver'

class TimeServer < GServer
  def serve(io)
    if io.gets =~ /^get_current_time$/
      io.puts(Time.now.to_s)
    end
  end
end

server = TimeServer.new( 9797 )
server.audit = true
server.start

sleep( 60 )
