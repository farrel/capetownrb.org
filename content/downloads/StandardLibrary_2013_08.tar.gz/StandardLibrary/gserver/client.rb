require 'socket'

s = TCPSocket.new( 'localhost', 9797 )

s.puts( "get_current_time" )

puts s.gets
