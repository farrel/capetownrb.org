require 'drb/drb'

$SAFE = 1 # Disable eval

class TimeServer
  def get_current_time
    puts "SERVER: Got Request"
    return Time.now
  end
end

DRb.start_service('druby://localhost:8787', TimeServer.new)
DRb.thread.join
