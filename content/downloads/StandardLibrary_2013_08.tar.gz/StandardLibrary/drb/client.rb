require 'drb/drb'

DRb.start_service

time_server = DRbObject.new_with_uri('druby://localhost:8787')

puts time_server.get_current_time
