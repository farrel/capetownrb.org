require 'dbm'

DBM.open( 'simple' ) do |db|
  puts( "Name: #{ db[ 'name' ] }")
  puts( "Surname: #{ db[ 'surname' ] }")
end
