require 'dbm'

db = DBM.new( 'simple' )

db[ 'name' ] = "Farrel"
db[ 'surname' ] = "Lifson"

db.close
