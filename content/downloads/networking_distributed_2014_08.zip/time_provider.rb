require 'rinda/tuplespace'

DRb.start_service

tuplespace =  DRbObject.new(nil,"druby://#{ENV['SERVER_IP']}:2004")

id = rand(100000000)
puts("My ID is #{id}")

loop do
  tuple = tuplespace.take([:timequery,nil])
  puts("Received: #{tuple.join(',')}")
  sleep(rand(10))
  tuplespace.write([:time,tuple[1],id,Time.now])
end
