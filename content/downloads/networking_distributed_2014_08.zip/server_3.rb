require 'gserver'

class TimeServer < GServer
  def serve(io)
    sleep(rand(10))
    io.puts Time.now
  end
end

server = TimeServer.new(2002)
server.audit = true
server.start

gets
