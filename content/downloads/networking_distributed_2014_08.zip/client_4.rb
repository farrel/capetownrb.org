require 'drb/drb'

DRb.start_service

timeserver = DRbObject.new_with_uri("druby://#{ENV['SERVER_IP']}:2003")
start = Time.now
puts timeserver.get_current_time
puts "Finished in #{Integer(Time.now - start)}s"
