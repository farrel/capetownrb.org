require 'socket'

start = Time.now
puts "Connecting..."
socket = TCPSocket.new(ENV['SERVER_IP'], 2000)
puts "Received '#{socket.gets}'"
puts "Finished in #{Integer(Time.now - start)}s"
socket.close
