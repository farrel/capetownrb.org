require 'socket'


TCPServer.open('2000') do |server|
  loop do
    client = server.accept
    puts "Connection from #{client.peeraddr[3]}"
    sleep(rand(10))
    client.puts Time.now
    client.close
  end
end
