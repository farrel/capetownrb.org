require 'rinda/tuplespace'


tuplespace = Rinda::TupleSpace.new

DRb.start_service("druby://0.0.0.0:2004", tuplespace)

provider_observer = tuplespace.notify("write",[:time,nil,nil,nil])
Thread.new do
  provider_observer.each do |tuple|
    puts(tuple.join(','))
  end
end

query_observer = tuplespace.notify("write",[:timequery,nil])
Thread.new do
  query_observer.each do |tuple|
    puts(tuple.join(','))
  end
end

puts "Running..."

DRb.thread.join
