require 'rinda/tuplespace'

DRb.start_service

id = rand(100000000)
puts("My ID is #{id}")

tuplespace =  DRbObject.new(nil,"druby://#{ENV['SERVER_IP']}:2004")

loop do
  tuplespace.write([:timequery, id])
  tuple = tuplespace.take([:time,id,nil,nil])
  puts("The Time from #{tuple[2]} is #{tuple[3]}")
  sleep(2)
end
