require 'drb/drb'

class TimeServer
  def get_current_time
    puts "get_current_time called"
    sleep(rand(10))
    return Time.now
  end
end

$SAFE = 1   # disable eval() and friends

DRb.start_service("druby://0.0.0.0:2003", TimeServer.new)
DRb.thread.join
